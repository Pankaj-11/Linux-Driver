#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

pthread_mutex_t lock;
pthread_cond_t cond;
int ready = 0;

void* high_priority_thread(void* arg) {
    pthread_mutex_lock(&lock);
    while (!ready) {
        pthread_cond_wait(&cond, &lock);
    }
    printf("High priority task is running\n");
    pthread_mutex_unlock(&lock);
    return NULL;
}

void* low_priority_thread(void* arg) {
    printf("Low priority task is running\n");
    sleep(2);  // Simulate work
    pthread_mutex_lock(&lock);
    ready = 1;
    pthread_cond_signal(&cond);
    pthread_mutex_unlock(&lock);
    return NULL;
}

int main() {
    pthread_t high_priority, low_priority;

    pthread_mutex_init(&lock, NULL);
    pthread_cond_init(&cond, NULL);

    pthread_create(&high_priority, NULL, high_priority_thread, NULL);
    pthread_create(&low_priority, NULL, low_priority_thread, NULL);

    pthread_join(high_priority, NULL);
    pthread_join(low_priority, NULL);

    pthread_mutex_destroy(&lock);
    pthread_cond_destroy(&cond);

    return 0;
}

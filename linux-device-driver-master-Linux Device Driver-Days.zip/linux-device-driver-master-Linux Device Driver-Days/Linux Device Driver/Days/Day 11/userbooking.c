#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define TOTAL_TICKETS 250
pthread_mutex_t mutex;
int seatsavailable = TOTAL_TICKETS;
int number_of_operations;
int number_of_threads;

void *bookticket(void *args) {
    for (int a = 0; a < number_of_operations; a++) {
        pthread_mutex_lock(&mutex);
        if (seatsavailable > 0) {
            seatsavailable--;
        }
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

void *cancelticket(void *args) {
    for (int a = 0; a < number_of_operations; a++) {
        pthread_mutex_lock(&mutex);
        if (seatsavailable < TOTAL_TICKETS) {
            seatsavailable++;
        }
        pthread_mutex_unlock(&mutex);
    }
    return NULL;
}

int main() {
    printf("Enter the number of threads: ");
    scanf("%d", &number_of_threads);
    printf("Enter the number of operations per thread: ");
    scanf("%d", &number_of_operations);

    pthread_t threads[number_of_threads];
    pthread_mutex_init(&mutex, NULL);

    for (int i = 0; i < number_of_threads / 2; i++) {
        if (pthread_create(&threads[i], NULL, bookticket, NULL) != 0) {
            perror("Failed to create booking thread");
            return 1;
        }
    }

    for (int i = number_of_threads / 2; i < number_of_threads; i++) {
        if (pthread_create(&threads[i], NULL, cancelticket, NULL) != 0) {
            perror("Failed to create cancellation thread");
            return 1;
        }
    }

    for (int i = 0; i < number_of_threads; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&mutex);
    printf("The final number of available seats is %d\n", seatsavailable);

    return 0;
}

#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#define NUMBER_OF_THREADS 15
#define NUMBER_OF_OPERATIONS 50000
#define TOTAL_TICKETS 250
pthread_mutex_t mutex;
int seatsavailable = TOTAL_TICKETS;

void *bookticket(void *args){
        int a=0;
        for(a=0; a<=NUMBER_OF_OPERATIONS; a++)
        {
                pthread_mutex_lock(&mutex);
                if ( seatsavailable > 0)
                {
                        seatsavailable--;
                }
                pthread_mutex_unlock(&mutex);
                //printf("the balance is %d",balance);
        }
        return NULL;
}
void *cancelticket(void *args){
        int a=0;
        for(a=0; a<=NUMBER_OF_OPERATIONS; a++)
        {
                pthread_mutex_lock(&mutex);
                if( seatsavailable < TOTAL_TICKETS )
                {
                        seatsavailable++;
                }
                pthread_mutex_unlock(&mutex);
        }
        return NULL;
}

int main()
{
        pthread_t threads[NUMBER_OF_THREADS];
        pthread_mutex_init(&mutex,NULL);
        int i;
        for(i=0; i<(NUMBER_OF_THREADS/2); i++){
        if (pthread_create(&threads[i],NULL,bookticket,NULL)!=0){
                perror("failed to create deposit thread ");
                printf("the no of threads are %d",NUMBER_OF_THREADS);
                return 1;
                }
        }

        for(;i<(NUMBER_OF_THREADS); i++){
        if (pthread_create(&threads[i],NULL,cancelticket,NULL)!=0){
                perror("failed to create withdraw thread");
                return 1;
        }
        }

       for(i=0;i<NUMBER_OF_THREADS;i++){
                pthread_join(threads[i],NULL);
        }
        pthread_mutex_destroy(&mutex);
        printf("the final balance is %d\n",seatsavailable);
        return 0;
}

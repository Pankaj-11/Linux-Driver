#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

void interrupt_handler(int signum) {
    printf("Interrupt received: %d\n", signum);
}

int main() {
    signal(SIGINT, interrupt_handler);  // Register interrupt handler

    while (1) {
        printf("Process is running\n");
        sleep(1);  // Simulate process context
    }

    return 0;
}

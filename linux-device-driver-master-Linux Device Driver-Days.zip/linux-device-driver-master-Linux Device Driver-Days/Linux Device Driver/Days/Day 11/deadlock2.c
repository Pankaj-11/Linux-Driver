#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t lock1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t lock2 = PTHREAD_MUTEX_INITIALIZER;

volatile int deadlock_detected = 0;

void* process_1(void* arg) {
    while (!deadlock_detected) {
        printf("Process 1: Attempting to acquire lock1\n");
        pthread_mutex_lock(&lock1);
        printf("Process 1: Acquired lock1\n");
        sleep(1); 

        printf("Process 1: Attempting to acquire lock2\n");
        if (pthread_mutex_trylock(&lock2) == 0) {
            printf("Process 1: Acquired lock2\n");
    
            printf("Process 1: Working with both resources\n");
            pthread_mutex_unlock(&lock2);
            printf("Process 1: Released lock2\n");
        } else {
            printf("Process 1: Could not acquire lock2, releasing lock1\n");
            pthread_mutex_unlock(&lock1);
            deadlock_detected = 1;
        }
        pthread_mutex_unlock(&lock1);
        if (deadlock_detected) break;
        sleep(1);
    }
    return NULL;
}

void* process_2(void* arg) {
    while (!deadlock_detected) {
        printf("Process 2: Attempting to acquire lock2\n");
        pthread_mutex_lock(&lock2);
        printf("Process 2: Acquired lock2\n");
        sleep(1);  

        printf("Process 2: Attempting to acquire lock1\n");
        if (pthread_mutex_trylock(&lock1) == 0) {
            printf("Process 2: Acquired lock1\n");
           
            printf("Process 2: Working with both resources\n");
            pthread_mutex_unlock(&lock1);
            printf("Process 2: Released lock1\n");
        } else {
            printf("Process 2: Could not acquire lock1, releasing lock2\n");
            pthread_mutex_unlock(&lock2);
            deadlock_detected = 1;
        }
        pthread_mutex_unlock(&lock2);
        if (deadlock_detected) break;
        sleep(1);
    }
    return NULL;
}

int main() {
    pthread_t thread1, thread2;

    pthread_create(&thread1, NULL, process_1, NULL);
    pthread_create(&thread2, NULL, process_2, NULL);

    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    if (deadlock_detected) {
        printf("Deadlock detected. Recovered by terminating one thread.\n");
    } else {
        printf("Completed without deadlock.\n");
    }

    return 0;
}

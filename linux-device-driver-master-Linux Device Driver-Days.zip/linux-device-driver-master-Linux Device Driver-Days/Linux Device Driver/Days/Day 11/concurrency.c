#include <pthread.h>
#include <stdio.h>
#include <unistd.h>

void* thread_function(void* arg) {
    int id = *((int*)arg);
    for(int i = 0; i < 5; i++) {
        printf("Thread %d is running\n", id);
        sleep(1);  // Simulate work
    }
    return NULL;
}

int main() {
    pthread_t threads[2];
    int thread_ids[2] = {1, 2};

    // Create two threads
    pthread_create(&threads[0], NULL, thread_function, &thread_ids[0]);
    pthread_create(&threads[1], NULL, thread_function, &thread_ids[1]);

    // Wait for threads to complete
    pthread_join(threads[0], NULL);
    pthread_join(threads[1], NULL);

    return 0;
}

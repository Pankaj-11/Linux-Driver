#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

pthread_mutex_t lock1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t lock2 = PTHREAD_MUTEX_INITIALIZER;

void* process_1(void* arg) {
    while (1) {
        printf("Process 1: Attempting to acquire lock1\n");
        if (pthread_mutex_trylock(&lock1) == 0) {
            printf("Process 1: Acquired lock1\n");
            sleep(1);  // Simulate some work with lock1

            printf("Process 1: Attempting to acquire lock2\n");
            if (pthread_mutex_trylock(&lock2) == 0) {
                printf("Process 1: Acquired lock2\n");
                // Do some work with both locks acquired
                printf("Process 1: Working with both resources\n");
                pthread_mutex_unlock(&lock2);
                printf("Process 1: Released lock2\n");
                pthread_mutex_unlock(&lock1);
                printf("Process 1: Released lock1\n");
                break;
            }
            pthread_mutex_unlock(&lock1);
            printf("Process 1: Released lock1\n");
        }
        sleep(1);
    }
    return NULL;
}

void* process_2(void* arg) {
    while (1) {
        printf("Process 2: Attempting to acquire lock2\n");
        if (pthread_mutex_trylock(&lock2) == 0) {
            printf("Process 2: Acquired lock2\n");
            sleep(1);  // Simulate some work with lock2

            printf("Process 2: Attempting to acquire lock1\n");
            if (pthread_mutex_trylock(&lock1) == 0) {
                printf("Process 2: Acquired lock1\n");
                // Do some work with both locks acquired
                printf("Process 2: Working with both resources\n");
                pthread_mutex_unlock(&lock1);
                printf("Process 2: Released lock1\n");
                pthread_mutex_unlock(&lock2);
                printf("Process 2: Released lock2\n");
                break;
            }
            pthread_mutex_unlock(&lock2);
            printf("Process 2: Released lock2\n");
        }
        sleep(1);
    }
    return NULL;
}

int main() {
    pthread_t thread1, thread2;

    // Creating threads
    pthread_create(&thread1, NULL, process_1, NULL);
    pthread_create(&thread2, NULL, process_2, NULL);

    // Joining threads
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    return 0;
}

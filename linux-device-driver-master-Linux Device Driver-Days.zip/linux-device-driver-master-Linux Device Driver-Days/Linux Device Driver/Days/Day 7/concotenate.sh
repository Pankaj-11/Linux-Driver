echo "Ente the first string : "
read string1
echo "Enter the second string : "
read string2
result="${string1}${string2:+}${string2}"
echo "The concatenated string is : $result"

a=10
b=40
sum=$((a+b))
echo "Sum of $a and $b is : $sum"

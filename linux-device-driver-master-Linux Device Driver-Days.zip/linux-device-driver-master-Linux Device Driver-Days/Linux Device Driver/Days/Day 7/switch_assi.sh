echo "Menu::"
echo "1. Display the current date and time."
echo "2. List the files int the current directory."
echo "3. Show the current user."
echo "4. Exit."
echo "Enter your choice : "
read choice

case $choice in
	1)
		date
		;;
	2)
		ls
		;;
	3)
		whoami
		;;
	4)
		echo "Exiting.."
		exit 0
		;;
	*)
		echo "Invalid choice."
		;;
esac

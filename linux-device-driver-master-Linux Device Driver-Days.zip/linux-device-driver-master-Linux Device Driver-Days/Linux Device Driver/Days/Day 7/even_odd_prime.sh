read -p "Enter a number : " num


if [ $((num % 2)) -eq 0 ]; then
	echo "$num is even."
else
	echo "$num is odd."
fi

is_prime=1
if [ $num -eq 2 ]; then
	is_prime=1
elif [ $((num % 2)) -eq 0 ] || [ $num -eq 1 ]; then
	is_prime=0
else
	for((i = 3; i * i <= num; i+= 2)); do
		if [ $((num % i)) -eq 0 ]; then
			is_prime=0
			break
		fi
	done
fi

if [ $is_prime -eq 1 ]; then
	echo "$num is prime number."
else
	echo "$num is not a prime number."
fi


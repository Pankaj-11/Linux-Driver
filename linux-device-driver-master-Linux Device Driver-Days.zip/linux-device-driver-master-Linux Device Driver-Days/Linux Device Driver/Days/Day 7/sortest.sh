echo "Enter five numbers"
read n1 n2 n3 n4 n5

smallest=$(echo "$n1 $n2 $n3 $n4 $n5" | tr ' ' '\n' | sort -n | head -1)

echo "Th smallest number is : $smallest"

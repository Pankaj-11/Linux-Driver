#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <linux/ioctl.h>

 

#define DEVICE_PATH "simple_char_dev"
#define IOCTL_SET_MSG _IOW('a', 'a', char*)

 

int main() {
    int fd;
    char message[] = "Hello from user space";

 

    fd = open(DEVICE_PATH, O_RDWR);
    if (fd < 0) {
        perror("Failed to open the device");
        return -1;
    }
     if (ioctl(fd, IOCTL_SET_MSG, message) < 0) {
        perror("Failed to send IOCTL message");
        close(fd);
        return -1;
    }



    printf("IOCTL message sent\n");
    close(fd);
    return 0;
}

#include <linux/module.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/ioctl.h>

#define DEVICE_NAME "simple_char_dev"
#define BUFFER_SIZE 1024
#define IOCTL_SET_MSG _IOW('a', 'a', char*)

static int major;
static char device_buffer[BUFFER_SIZE];
static int open_count = 0;

static int device_open(struct inode *inode, struct file *file) {
    open_count++;
    printk(KERN_INFO "Device opened %d times\n", open_count);
    return 0;
}

static int device_release(struct inode *inode, struct file *file) {
    printk(KERN_INFO "Device closed\n");
    return 0;
}
static ssize_t device_read(struct file *file, char __user *buffer, size_t len, loff_t *offset) {
    int bytes_read = len < BUFFER_SIZE ? len : BUFFER_SIZE;
    if (copy_to_user(buffer, device_buffer, bytes_read) != 0) {
        return -EFAULT;
    }
    return bytes_read;
}

static ssize_t device_write(struct file *file, const char __user *buffer, size_t len, loff_t *offset) {
    int bytes_to_write = len < BUFFER_SIZE ? len : BUFFER_SIZE;
    if (copy_from_user(device_buffer, buffer, bytes_to_write) != 0) {
        return -EFAULT;
    }
    return bytes_to_write;
}
 
static long device_ioctl(struct file *file, unsigned int cmd, unsigned long arg) {
    switch (cmd) {
        case IOCTL_SET_MSG:
            if (copy_from_user(device_buffer, (char*)arg, BUFFER_SIZE) != 0) {
                return -EFAULT;
            }
            printk(KERN_INFO "Received from user: %s\n", device_buffer);
            break;
        default:
            return -EINVAL;
    }
    return 0;
}

static struct file_operations fops = {
    .open = device_open,
    .release = device_release,
    .read = device_read,
    .write = device_write,
    .unlocked_ioctl = device_ioctl
};

static int __init char_dev_init(void) 
{
	major = register_chrdev(0, DEVICE_NAME, &fops);
    if (major < 0) {
        printk(KERN_ALERT "Failed to register character device\n");
        return major;
    }
    printk(KERN_INFO "Registered character device with major number %d\n", major);
    return 0;
}

static void __exit char_dev_exit(void) {
    unregister_chrdev(major, DEVICE_NAME);
    printk(KERN_INFO "Unregistered character device\n");
}

module_init(char_dev_init);
module_exit(char_dev_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("A simple character device driver example");


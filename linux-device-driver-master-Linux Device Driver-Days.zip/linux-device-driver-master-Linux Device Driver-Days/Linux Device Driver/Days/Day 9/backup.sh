compress_file() {
    local filename=$1
    local compression_type=$2
   
    if [ ! -f "$filename" ]; then
        echo "File $filename not found."
        return 1
    fi

    case $compression_type in
        "gzip")
            gzip "$filename"
            ;;
        "bzip2")
            bzip2 "$filename"
            ;;
        "zip")
            zip "$filename.zip" "$filename"
            ;;
        *)
            echo "Unsupported compression type: $compression_type"
            return 1
            ;;
    esac

    echo "File $filename compressed as $compression_type."
}

echo "Enter the filename"
read -r filename
echo "Enter the compression type"
read -r compression_type
compress_file "$filename" "$compression_type"


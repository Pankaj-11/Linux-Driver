Manageuser()
{
	local operation=$1
	local user=$2
	local group=${3:-users}

	case $operation in
		add)
			sudo useradd -m -g "$group" "$username"
			echo "user $username added"
			;;
		delete)
			sudo userdel -r "$username"
			echo "user $username deleted"
			;;
		list)
			awk -F: '{ print $1 }' /etc/passwd
			;;
		*)
			echo "Invalid Operation"
			;;
	esac
}

echo "Enter operation (add/delete/list)"
read -r operation

if [ "$operation" == "add" ]; then
	echo "Enter username:"
	read -r username
	echo "Enter group name"
	read -r group
	Manageuser "$operation" "$username" "$group"
elif [ "$operation" == "delete" ]; then
	echo "Enter username"
	read -r username
	Manageuser "$operation" "$username"

elif [ "$operation" == "list" ]; then
	Manageuser "$operation" 
else
	echo "Invalid operaton"
fi


add_user()
{
echo "Enter username to add :"
read -r usr
sudo adduser $usr
}
del_user()
{
echo "Enter username to delete :"
read -r usr
sudo deluser $usr
}
list_user()
{
echo "Listof all users  :"
cut -d: -f1 /etc/passwd
}

while true; do
echo "User management"
echo "1.Add user"
echo "2.Delete user"
echo "3.List all user"
echo "4.Exit"
echo "Enter the choice :"
read c

case $c in
1)
add_user
;;
2)
del_user
;;
3)
list_user
;;
4)
exit
;;
*)
echo "Invalid choice"
;;
esac
done 

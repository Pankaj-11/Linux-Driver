generate_random_number() {
    echo $((RANDOM))
}

# Function to display usage information
display_usage() {
    echo "Usage: $0 -s <source_folder> -d <destination_folder> [-n <backup_name>] [-t <compress_type>]"
    echo ""
    echo "Options:"
    echo "  -s, --source          Source folder to back up."
    echo "  -d, --destination     Destination folder to store the backup."
    echo "  -n, --name            (Optional) Backup file name."
    echo "  -t, --type            (Optional) Compression type (tar.gz or zip). Default is tar.gz."
    echo "  -h, --help            Display this help message and exit."
}

# Parse options and arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -s|--source)
            source_folder="$2"
            shift 2
            ;;
        -d|--destination)
            destination_folder="$2"
            shift 2
            ;;
        -n|--name)
            backup_name="$2"
            shift 2
            ;;
        -t|--type)
            compress_type="$2"
            shift 2
            ;;
        -h|--help)
            display_usage
            exit 0
            ;;
        *)
            echo "Invalid option: $1" >&2
            display_usage
            exit 1
            ;;
    esac
done

# Check if source and destination folders are provided
if [[ -z "$source_folder" || -z "$destination_folder" ]]; then
    echo "Source and destination folders are required."
    display_usage
    exit 1
fi

# Set default compression type if not provided
compress_type=${compress_type:-tar.gz}

# Generate a random number
random_number=$(generate_random_number)

# Set default backup name if not provided
if [[ -z "$backup_name" ]]; then
    backup_name="backup_${random_number}.$compress_type"
else
    backup_name="${backup_name}_${random_number}.$compress_type"
fi

# Create the backup
timestamp=$(date +"%Y%m%d%H%M%S")
backup_file="$destination_folder/$backup_name"

case $compress_type in
    tar.gz)
        tar -czf "$backup_file" -C "$source_folder" .
        ;;
    zip)
        zip -r "$backup_file" "$source_folder"
        ;;
    *)
        echo "Unsupported compression type: $compress_type"
        display_usage
        exit 1
        ;;
esac

# Check if the backup was successful
if [[ $? -eq 0 ]]; then
    echo "Backup created successfully: $backup_file"
else
    echo "Failed to create backup."
fi



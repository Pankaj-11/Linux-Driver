function display_usage {
  echo "Usage: $0 [OPTION] [USERNAME]"
  echo ""
  echo "Options:"
  echo "  -a, --add       Add a new user account."
  echo "  -d, --delete    Delete an existing user account."
  echo "  -l, --list      List all user accounts on the system."
  echo "  -h, --help      Display this help and exit."
  echo ""
  echo "  USERNAME       (Required for -a and -d) Username for the account." 
  }

if [[ $EUID -ne 0 ]]; then
  echo "This script must be run with root privileges."
  exit 1
fi

while getopts ":a:d:lh" opt; do
  case $opt in
    a)
      action="add"
      username="$OPTARG"
      ;;
    d)
      action="delete"
      username="$OPTARG"
      ;;
    l)
      action="list"
      ;;
    h)
      action="help"
      ;;
    \?)
      echo "Invalid option: -$OPTARG" >&2
      display_usage
      exit 1
      ;;
  esac
done

if [[ -z "$action" ]]; then
  display_usage
  exit 1
fi

case $action in
  add)

    if [[ -z "$username" ]]; then
    echo "Username is required for adding a user."
      display_usage
      exit 1
    fi


    useradd -m "$username"


    if [[ $? -eq 0 ]]; then
      echo "User '$username' created successfully."


    else
      echo "Failed to create user '$username'."
    fi
    ;;
  delete)

    if [[ -z "$username" ]]; then
      echo "Username is required for deleting a user."
      display_usage
      exit 1
    fi

    userdel -r "$username"
     if [[ $? -eq 0 ]]; then
      echo "User '$username' deleted successfully."
    else
      echo "Failed to delete user '$username'."
    fi
    ;;
  list)

    users=$(cut -d ':' -f1 /etc/passwd)
    echo "List of users:"
    echo "$users"
    ;;
  help)
    display_usage
    exit 0
    ;;
esac

log_sys_stats () {
	local interval=$1
	local logfiles=$2
	local iterations=${3:-12}

		for (( i = 1; i <= iterations; i++ )); do
		echo "Logging system status (iteration $i/iteration/$iteration).." >> "$log_file"
		echo "CPU Usage: " >> "$log_file"
		top -b -n 1 ! grep "Cpu(s)" >> "$log_file"
		echo "Memory usage: " >> "$log_file"
		free -m >> "log_file"
		echo "Disk Usage: " >> "$log_file"
		df -h >> "$log_file"
		echo "---------------------------------------" >> "$log_file"
		sleep "$interval"
   	done
   	
   	echo "System stats logged to $log_file"
   	
}

echo "Enter the logging interval in seconds"
read -r interval

echo "Enter the number of iterations"
read -r iterations

echo "Enter the log file name"
read -r log_file

if [ -z "$iterations" ]; then
	iterations=10
fi

if [ -z "$interval" ] || [ -z "log_file" ]; then
	 echo "usage: $0 interval log_file [iterations]"
	 exit 1
fi

log_sys_stats "$interval" "$log_file" "$iterations"

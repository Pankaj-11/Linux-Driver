#include <stdio.h>
#include <string.h>
 
void vulnerable_function(char *input) {
    char buffer[10];
    strncpy(buffer, input, sizeof(buffer) -1); // Vulnerable to buffer overrun
    buffer[sizeof(buffer) -1] = '\0';
    printf("Buffer: %s\n", buffer);
}
 
int main(int argc, char *argv[]) {
    if (argc > 1) {
        vulnerable_function(argv[1]);
    } else {
        printf("Usage: %s <input>\n", argv[0]);
    }
    return 0;
}

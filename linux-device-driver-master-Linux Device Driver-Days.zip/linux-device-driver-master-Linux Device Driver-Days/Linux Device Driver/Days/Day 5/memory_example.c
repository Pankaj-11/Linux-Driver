#include <stdlib.h>
#include <stdio.h>

int main() {
    int *array = (int*) malloc(100 * sizeof(int));
    if (array == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }
    for (int i = 0; i < 100; i++) {
        array[i] = i;
    }
    //printf("Elements of the array : \n");
    //for(int i=0;i<100;i++)
    //{
    //printf("%d ",array[i]);
    //}
    //printf("\n");
    free(array);
    return 0;
}

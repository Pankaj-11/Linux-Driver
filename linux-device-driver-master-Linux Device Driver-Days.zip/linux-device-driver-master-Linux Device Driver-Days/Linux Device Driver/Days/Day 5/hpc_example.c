#include <stdlib.h>
#include <stdio.h>
 
#define ARRAY_SIZE 1000000
 
int main() {
    double *array = (double*) malloc(ARRAY_SIZE * sizeof(double));
    if (array == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }
    for (int i = 0; i < ARRAY_SIZE; i++) {
        array[i] = (double) i / 2.0;
    }
    printf("Array allocated and initialized.\n");
    free(array);
    return 0;
}

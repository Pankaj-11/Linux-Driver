numbers=( 34 54 12 78 90)

len=${#numbers[@]}

for ((i=0; i<len-1; i++)); do
        for ((j=0; j<len-i-1; j++)); do
                if [ ${numbers[j]} -lt ${numbers[j+1]} ]; then
                        temp=${numbers[j]}
                        numbers[j]=${numbers[j+1]}
                        numbers[j+1]=$temp
                fi
        done
done

echo "Sorted array in ascending order:"
for num in "${numbers[@]}"; do
        echo "$num"
done


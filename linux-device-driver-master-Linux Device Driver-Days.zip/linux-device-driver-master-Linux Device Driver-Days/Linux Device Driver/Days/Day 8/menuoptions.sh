declare -A menu=(
    ["Tiffins"]="Idli :20 Dosa :30 Pongal :25 Upma :25"
    ["Snacks"]="Samosa :15 Pakoda :20 Mixer :25"
    ["Drinks"]="Tea :10 Coffee :15 Juice :20"
    ["Main Course"]="Curry :50 Rice :40 Roti :15 Naan :20"
)

display_menu() {
    echo "Menu:"
    for category in "${!menu[@]}"; do
        echo "$category:"
        for item_price in ${menu[$category]}; do
		item=$(echo $item_price | cut -d ':' -f1)
		price=$(echo $item_price | cut -d ':' -f2)
            echo " - $item : $price"
        done
    done
}

calculate_total() {
    local total=0
    for item in "${order[@]}"; do
        for category in "${!menu[@]}"; do
		for item_price in ${menu[$category]}; do
			if [[ "item_price" == *"$item"* ]]; then
				price=$(echo $item_price | cut -d ':' -f2)
				total=$((total + $price))
            fi
   	 done
     done
done
    echo "Total: $total"
}

main() {
    declare -a order=()
    display_menu
    while true; do
        read -p "Enter item to order (or '0' to finish): " item
        if [[ "$item" == "0" ]]; then
            break
        fi
        order+=("$item")
    done
    calculate_total
}

main

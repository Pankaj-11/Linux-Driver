names=("Logesh" "Kavin" "Kamalesh" "Praveen" "Yuva")
len=${#names[@]}

for ((i=0; i<len; i+=2)) do
	echo "Name, ${names[$i]}"
done

for name in "${names[@]}"; do
	echo "Name, $name"
done

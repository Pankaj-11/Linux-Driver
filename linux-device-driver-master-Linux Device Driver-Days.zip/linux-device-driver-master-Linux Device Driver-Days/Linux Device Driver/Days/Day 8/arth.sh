add () {
	result=$(($1 + $2))
	echo "Sum: $result"
}

sub() {
	result=$(($1 - $2))
	echo "Subtract: $result"
}

mul() {
	result=$(($1 * $2))
	echo "Multiply: $result"
}
div() {
	result=$(($1 / $2))
	echo "Division: $result"
}

echo "Choose an Operate:"
echo "1. Add"
echo "2. Subtract"
echo "3. Multiply"
echo "4. Division"
read choice

echo "Enter two numbers : "
read num1 num2

case $choice in

	1) add $num1 $num2 ;;
	2) sub $num1 $num2 ;;
	3) mul $num1 $num2 ;;
	4) div $num1 $num2 ;;
	*) echo "Invalid choice" ;;
esac

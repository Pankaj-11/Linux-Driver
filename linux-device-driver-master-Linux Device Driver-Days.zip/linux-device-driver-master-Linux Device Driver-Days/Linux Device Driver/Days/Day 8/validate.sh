echo "Enter Something"
read input

if [[ $input =~ ^-?[0-9]+$ ]]; then
	echo "Input is ineteger"
elif [[ $input =~ ^-?[0-9]*\.[0-9]+$ ]]; then
	echo "Input is double or float"
else
	echo "The input is string"
fi

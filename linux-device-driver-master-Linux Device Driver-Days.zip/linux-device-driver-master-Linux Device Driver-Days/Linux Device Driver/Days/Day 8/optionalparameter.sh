arithmetic_operation()
{
	local operation=$1
	local num1=${2:-0}
	local num2=${3:-1}

	case $operation in
		add) 
			result=$((num1 + num2))
			echo "Addition result is $result"
			;;
		sub)
			result=$((num1 - num2))
			echo "Substraction result is $result"
			;;
		mul)
			result=$((num1 * num2))
			echo "Multiplication result is $result"
			;;
		div)
			if [ $num2 -ne 0 ]; then
				result=$((num / num2))
				echo "Division result is $result"
			else
				echo "Number can not be divied by 0"
			fi
			;;
		*)
			echo "Invalid input"
			;;
	esac
}

echo "enter the operation (add/sub/mul/div) ; "
read -r operation
echo "Enter first number : "
read -r num1
echo "Enter second number : "
read -r num2

arithmetic_operation "$operation" "$num1" "$num2"


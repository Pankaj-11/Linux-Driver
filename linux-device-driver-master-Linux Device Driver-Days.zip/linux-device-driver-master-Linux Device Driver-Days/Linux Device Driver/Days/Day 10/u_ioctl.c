#include<stdio.h>
#include<fcntl.h>
#include<linux/ioctl.h>

#define IOCTL_RESET_BUFFER _IOW('a', 'a', int)
#define DEVICE_NAME "simple_char_dev"
int main(){
	int fd = open(DEVICE_NAME, O_RDWR);
	if(fd<0) {
		printf("Failed to open the device\n");
		return -1;
	}
	if(ioctl(fd, IOCTL_RESET_BUFFER, NULL)<0){
		printf("Failed to reset the buffer\n");
	}
	else{
		printf("Buffer reset successfull\n");
	}
	close(fd);
	return 0;
}

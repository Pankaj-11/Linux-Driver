file_url="https://github.com/stedolan/jq/releases/latest/download/jq-linux64"

file_name="jq-linux64"

unpack_dir="jq"

target_path="/usr/local/bin/jq"

wget "$file_url" -O "$file_name"
if [ -f "$file_name" ]; then
	echo "Download was successfull"
else
	echo "Download failed"
	exit 1;
fi

chmod +x "$file_name"

if [ $? -ne 0 ]; then
	echo "Failed to make excutable"
	exit 1;
fi 

sudo mv "$file_name" "$target_path"

if command -v jq &> /dev/null; then
	echo "jq Installed successfull"
else
	echo "jq Install failed"
	exit 1;
fi


